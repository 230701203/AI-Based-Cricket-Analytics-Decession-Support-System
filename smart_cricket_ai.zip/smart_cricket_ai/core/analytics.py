"""
core/analytics.py

Two jobs:
1. compute_batting_stats / compute_bowling_stats — turn raw per-match rows
   into career aggregate stats (Module 2).
2. calculate_performance_scores / get_strengths_weaknesses / get_team_ratings
   — the rule-based "AI" scoring engine (Module 4). This is intentionally
   a simple weighted formula, NOT machine learning yet. Swap this out for
   a trained Random Forest / XGBoost model later without changing the
   function signatures the templates depend on.
"""

from django.db.models import Sum, Max, Count


def compute_batting_stats(qs):
    """qs: a BattingPerformance queryset for one player (optionally filtered by format)."""
    agg = qs.aggregate(
        innings=Count('id'),
        runs=Sum('runs'),
        balls_faced=Sum('balls_faced'),
        fours=Sum('fours'),
        sixes=Sum('sixes'),
        highest_score=Max('runs'),
    )
    innings = agg['innings'] or 0
    runs = agg['runs'] or 0
    balls_faced = agg['balls_faced'] or 0
    outs = qs.filter(is_out=True).count()

    average = round(runs / outs, 2) if outs > 0 else (runs if runs else 0)
    strike_rate = round((runs / balls_faced) * 100, 2) if balls_faced > 0 else 0.0
    fifties = qs.filter(runs__gte=50, runs__lt=100).count()
    hundreds = qs.filter(runs__gte=100).count()

    # matches != innings in theory, but for this simplified system 1 row = 1 match appearance
    matches = innings

    return {
        'matches': matches,
        'innings': innings,
        'runs': runs,
        'highest_score': agg['highest_score'] or 0,
        'average': average,
        'strike_rate': strike_rate,
        'fifties': fifties,
        'hundreds': hundreds,
        'fours': agg['fours'] or 0,
        'sixes': agg['sixes'] or 0,
        'balls_faced': balls_faced,
    }


def compute_bowling_stats(qs):
    """qs: a BowlingPerformance queryset for one player (optionally filtered by format)."""
    agg = qs.aggregate(
        matches=Count('id'),
        overs=Sum('overs'),
        wickets=Sum('wickets'),
        runs_conceded=Sum('runs_conceded'),
        maidens=Sum('maidens'),
    )
    matches = agg['matches'] or 0
    overs = agg['overs'] or 0
    wickets = agg['wickets'] or 0
    runs_conceded = agg['runs_conceded'] or 0

    economy = round(runs_conceded / overs, 2) if overs > 0 else 0.0
    bowling_average = round(runs_conceded / wickets, 2) if wickets > 0 else 0.0
    balls_bowled = overs * 6  # approximation treating .1/.2 as fraction-of-over, fine for a demo
    bowling_sr = round(balls_bowled / wickets, 2) if wickets > 0 else 0.0

    best = qs.order_by('-wickets', 'runs_conceded').first()
    best_bowling = f"{best.wickets}/{best.runs_conceded}" if best else "-"

    return {
        'matches': matches,
        'overs': overs,
        'wickets': wickets,
        'runs_conceded': runs_conceded,
        'economy': economy,
        'bowling_average': bowling_average,
        'bowling_strike_rate': bowling_sr,
        'best_bowling': best_bowling,
        'maidens': agg['maidens'] or 0,
    }


# ---------------------------------------------------------------------------
# Performance scoring engine (Module 4.1)
# ---------------------------------------------------------------------------

def _clamp(value, low=0, high=100):
    return max(low, min(high, value))


def _recent_form_score(player, format=None):
    qs = player.battingperformance_set.all().order_by('-match__date')
    if format:
        qs = qs.filter(match__format=format)
    recent = list(qs[:5])
    if not recent:
        return None

    weights = [1.5, 1.3, 1.1, 1.0, 0.9][:len(recent)]
    scored = []
    for perf, w in zip(recent, weights):
        # crude per-innings score: runs contribution + strike rate bonus, capped 0-100
        sr_bonus = min(perf.strike_rate() / 2, 30)
        innings_score = _clamp(perf.runs * 0.8 + sr_bonus)
        scored.append(innings_score * w)

    return round(sum(scored) / sum(weights), 1)


def calculate_performance_scores(player, format=None):
    batting = player.get_career_batting_stats(format=format)
    bowling = player.get_career_bowling_stats(format=format)

    # Batting score: normalized average + strike rate, benchmarked loosely
    # against average=40 / SR=130 as a solid baseline.
    batting_score = None
    if batting['innings'] > 0:
        avg_component = _clamp((batting['average'] / 40) * 60)
        sr_component = _clamp((batting['strike_rate'] / 130) * 40)
        batting_score = round(_clamp(avg_component + sr_component), 1)

    # Bowling score: lower economy/average is better.
    bowling_score = None
    if bowling['matches'] > 0 and bowling['wickets'] > 0:
        economy_component = _clamp((8 / max(bowling['economy'], 1)) * 40, 0, 40)
        avg_component = _clamp((25 / max(bowling['bowling_average'], 1)) * 40, 0, 40)
        wickets_component = _clamp(bowling['wickets'] * 2, 0, 20)
        bowling_score = round(_clamp(economy_component + avg_component + wickets_component), 1)

    # Fielding: not tracked in detail yet beyond raw counts -> placeholder baseline
    total_field_actions = player.catches + player.run_outs + player.stumpings
    fielding_score = round(_clamp(60 + total_field_actions * 2), 1) if total_field_actions else 75.0

    recent_form_score = _recent_form_score(player, format=format)

    components = [s for s in [batting_score, bowling_score, fielding_score, recent_form_score] if s is not None]
    overall_score = round(sum(components) / len(components), 1) if components else 0.0

    if overall_score >= 90:
        classification = "Excellent"
    elif overall_score >= 75:
        classification = "Very Good"
    elif overall_score >= 60:
        classification = "Good"
    elif overall_score >= 40:
        classification = "Average"
    else:
        classification = "Poor"

    return {
        'batting_score': batting_score,
        'bowling_score': bowling_score,
        'fielding_score': fielding_score,
        'recent_form_score': recent_form_score,
        'overall_score': overall_score,
        'classification': classification,
    }


def get_strengths_weaknesses(player, format=None):
    """Rule-based (threshold) strengths/weaknesses. Thresholds are placeholders -
    tune them once you have more real match data."""
    batting = player.get_career_batting_stats(format=format)
    bowling = player.get_career_bowling_stats(format=format)
    scores = calculate_performance_scores(player, format=format)

    strengths, weaknesses = [], []

    if batting['innings'] > 0:
        if batting['strike_rate'] > 130:
            strengths.append("High strike rate")
        elif batting['strike_rate'] < 100:
            weaknesses.append("Low strike rate")

        if batting['average'] > 40:
            strengths.append("Strong batting average")
        elif 0 < batting['average'] < 20:
            weaknesses.append("Inconsistent with the bat")

        if batting['balls_faced'] > 0:
            boundary_balls = batting['fours'] + batting['sixes']
            boundary_pct = (boundary_balls / batting['innings']) if batting['innings'] else 0
            if boundary_pct > 4:
                strengths.append("Excellent boundary hitting")

    if bowling['matches'] > 0 and bowling['wickets'] > 0:
        if bowling['economy'] < 6.5:
            strengths.append("Economical bowler")
        elif bowling['economy'] > 9:
            weaknesses.append("Leaks runs in the death overs")

        if bowling['bowling_average'] and bowling['bowling_average'] < 20:
            strengths.append("Consistent wicket-taker")

    if scores['recent_form_score'] is not None:
        if scores['recent_form_score'] > 80:
            strengths.append("Strong recent form")
        elif scores['recent_form_score'] < 40:
            weaknesses.append("Poor recent form")

    if not strengths:
        strengths.append("Not enough match data yet to identify strengths")
    if not weaknesses:
        weaknesses.append("Not enough match data yet to identify weaknesses")

    return strengths, weaknesses


def get_team_ratings(team):
    players = team.players.all()
    if not players:
        return {
            'batting_rating': 0, 'bowling_rating': 0,
            'fielding_rating': 0, 'overall_rating': 0,
            'strengths': [], 'weaknesses': [],
        }

    batting_scores, bowling_scores, fielding_scores, overall_scores = [], [], [], []
    economies = []
    spin_bowlers = 0

    for p in players:
        s = calculate_performance_scores(p)
        if s['batting_score'] is not None:
            batting_scores.append(s['batting_score'])
        if s['bowling_score'] is not None:
            bowling_scores.append(s['bowling_score'])
            bowling = p.get_career_bowling_stats()
            if bowling['economy']:
                economies.append(bowling['economy'])
        fielding_scores.append(s['fielding_score'])
        overall_scores.append(s['overall_score'])
        if 'spin' in (p.bowling_style or '').lower():
            spin_bowlers += 1

    def avg(lst):
        return round(sum(lst) / len(lst), 1) if lst else 0

    ratings = {
        'batting_rating': avg(batting_scores),
        'bowling_rating': avg(bowling_scores),
        'fielding_rating': avg(fielding_scores),
        'overall_rating': avg(overall_scores),
    }

    strengths, weaknesses = [], []
    if ratings['batting_rating'] >= 75:
        strengths.append("Strong batting line-up")
    if economies and (sum(economies) / len(economies)) < 7:
        strengths.append("Strong bowling attack")
    if spin_bowlers < 2:
        weaknesses.append("Limited spin options")
    if ratings['bowling_rating'] and ratings['bowling_rating'] < 60:
        weaknesses.append("Weak death bowling")
    if not strengths:
        strengths.append("Balanced squad, no standout strength yet")
    if not weaknesses:
        weaknesses.append("No major weakness identified yet")

    ratings['strengths'] = strengths
    ratings['weaknesses'] = weaknesses
    return ratings
