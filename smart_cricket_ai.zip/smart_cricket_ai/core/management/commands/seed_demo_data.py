import random
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from core.models import Team, Player

User = get_user_model()

FIRST_NAMES = [
    "Arjun", "Rohan", "Vikram", "Karan", "Aditya", "Suresh", "Rahul", "Manish",
    "Aakash", "Nikhil", "Sandeep", "Deepak", "Rajesh", "Anil", "Vivek", "Sameer",
    "Gaurav", "Harsh", "Yash", "Pranav",
]
LAST_NAMES = [
    "Sharma", "Verma", "Iyer", "Nair", "Reddy", "Patel", "Singh", "Gupta",
    "Kumar", "Rao", "Menon", "Joshi", "Chauhan", "Mishra", "Pillai", "Das",
    "Bose", "Kapoor", "Malhotra", "Yadav",
]

ROLES = ["Batsman", "Bowler", "All-rounder", "Wicketkeeper"]
BATTING_STYLES = ["Right hand", "Left hand"]
BOWLING_STYLES = [
    "Right-arm fast", "Left-arm fast", "Right-arm medium", "Left-arm medium",
    "Off spin", "Leg spin", "Left-arm orthodox", "None",
]


class Command(BaseCommand):
    help = "Seed demo teams, players, and 4 test login users for each role."

    def handle(self, *args, **options):
        team_names = ["Team A", "Team B", "Team C"]
        teams = []
        for name in team_names:
            team, _ = Team.objects.get_or_create(team_name=name)
            teams.append(team)
        self.stdout.write(self.style.SUCCESS(f"Teams ready: {[t.team_name for t in teams]}"))

        used_names = set()
        created_players = []
        target_count = 20

        while len(created_players) < target_count:
            name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            if name in used_names:
                continue
            used_names.add(name)

            role = ROLES[len(created_players) % len(ROLES)]  # spread roles evenly-ish
            bowling_style = "None" if role == "Batsman" else random.choice(BOWLING_STYLES[:-1])

            player = Player.objects.create(
                name=name,
                age=random.randint(19, 35),
                nationality="Indian",
                team=teams[len(created_players) % len(teams)],
                jersey_number=random.randint(1, 99),
                height_cm=round(random.uniform(165, 195), 1),
                weight_kg=round(random.uniform(60, 90), 1),
                role=role,
                batting_style=random.choice(BATTING_STYLES),
                bowling_style=bowling_style,
                catches=random.randint(0, 15),
                run_outs=random.randint(0, 5),
                stumpings=random.randint(0, 5) if role == "Wicketkeeper" else 0,
            )
            created_players.append(player)

        self.stdout.write(self.style.SUCCESS(f"Created {len(created_players)} players."))

        # Create 4 test login users, one per role, linking player1 to a real Player
        demo_users = [
            ("player1", "player", created_players[0]),
            ("coach1", "coach", None),
            ("analyst1", "analyst", None),
            ("mgmt1", "management", None),
        ]
        for username, role, player in demo_users:
            if not User.objects.filter(username=username).exists():
                user = User.objects.create_user(username=username, password="pass1234", role=role)
                if player:
                    user.player = player
                    user.save()
                self.stdout.write(self.style.SUCCESS(f"Created user {username}/pass1234 ({role})"))
            else:
                self.stdout.write(f"User {username} already exists, skipping.")

        self.stdout.write(self.style.SUCCESS("Seeding complete."))
