from django import forms
from django.forms import formset_factory
from .models import Player, Match


class PlayerForm(forms.ModelForm):
    class Meta:
        model = Player
        fields = [
            'name', 'age', 'date_of_birth', 'nationality', 'profile_picture',
            'team', 'jersey_number', 'height_cm', 'weight_kg',
            'role', 'batting_style', 'bowling_style',
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }


class MatchForm(forms.ModelForm):
    class Meta:
        model = Match
        fields = ['date', 'format', 'venue', 'team1', 'team2', 'toss_winner', 'toss_decision']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean(self):
        cleaned = super().clean()
        team1 = cleaned.get('team1')
        team2 = cleaned.get('team2')
        if team1 and team2 and team1 == team2:
            raise forms.ValidationError("Team 1 and Team 2 must be different.")
        return cleaned


class PlayerSearchForm(forms.Form):
    q = forms.CharField(required=False, label='')
    role = forms.ChoiceField(required=False, choices=[('', 'Any role')] + Player.ROLE_CHOICES)
    team = forms.CharField(required=False)  # populated dynamically in the view via a ModelChoiceField override
    batting_style = forms.ChoiceField(required=False, choices=[('', 'Any')] + Player.BATTING_STYLE_CHOICES)
    bowling_style = forms.ChoiceField(required=False, choices=[('', 'Any')] + Player.BOWLING_STYLE_CHOICES)


class BattingEntryForm(forms.Form):
    player_id = forms.IntegerField(widget=forms.HiddenInput())
    player_name = forms.CharField(required=False, disabled=True)
    runs = forms.IntegerField(min_value=0, initial=0)
    balls_faced = forms.IntegerField(min_value=0, initial=0)
    fours = forms.IntegerField(min_value=0, initial=0)
    sixes = forms.IntegerField(min_value=0, initial=0)
    is_out = forms.BooleanField(required=False, initial=True)


class BowlingEntryForm(forms.Form):
    player_id = forms.IntegerField(widget=forms.HiddenInput())
    player_name = forms.CharField(required=False, disabled=True)
    overs = forms.FloatField(min_value=0, initial=0)
    runs_conceded = forms.IntegerField(min_value=0, initial=0)
    wickets = forms.IntegerField(min_value=0, initial=0)
    maidens = forms.IntegerField(min_value=0, initial=0)


BattingFormSet = formset_factory(BattingEntryForm, extra=0)
BowlingFormSet = formset_factory(BowlingEntryForm, extra=0)


class MatchScoreSummaryForm(forms.Form):
    team1_score = forms.CharField(max_length=20, help_text='e.g. 186/6')
    team1_overs = forms.FloatField(min_value=0)
    team2_score = forms.CharField(max_length=20, help_text='e.g. 172/8')
    team2_overs = forms.FloatField(min_value=0)
