from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse

from .decorators import role_required
from .forms import (
    PlayerForm, MatchForm, BattingFormSet, BowlingFormSet, MatchScoreSummaryForm,
)
from .models import (
    Player, Team, Match, PlayingXI, BattingPerformance, BowlingPerformance,
)
from .analytics import calculate_performance_scores, get_strengths_weaknesses, get_team_ratings


ROLE_DASHBOARD_URL = {
    'player': 'dashboard_player',
    'coach': 'dashboard_coach',
    'analyst': 'dashboard_analyst',
    'management': 'dashboard_management',
}


# ---------------------------------------------------------------------------
# MODULE 1 — Auth
# ---------------------------------------------------------------------------

def login_view(request):
    if request.user.is_authenticated:
        return redirect(ROLE_DASHBOARD_URL.get(request.user.role, 'login'))

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect(ROLE_DASHBOARD_URL.get(user.role, 'login'))
        messages.error(request, "Invalid username or password.")
    return render(request, 'core/login.html')


def logout_view(request):
    auth_logout(request)
    return redirect('login')


def home_redirect(request):
    if request.user.is_authenticated:
        return redirect(ROLE_DASHBOARD_URL.get(request.user.role, 'login'))
    return redirect('login')


@role_required('player')
def dashboard_player(request):
    player = request.user.player
    context = {'player': player}
    if player:
        context['scores'] = calculate_performance_scores(player)
    return render(request, 'core/dashboard_player.html', context)


@role_required('coach')
def dashboard_coach(request):
    teams = Team.objects.all()
    team_ratings = [(t, get_team_ratings(t)) for t in teams]
    return render(request, 'core/dashboard_coach.html', {'team_ratings': team_ratings})


@role_required('analyst')
def dashboard_analyst(request):
    return render(request, 'core/dashboard_analyst.html')


@role_required('management')
def dashboard_management(request):
    teams = Team.objects.all()
    team_ratings = [(t, get_team_ratings(t)) for t in teams]
    return render(request, 'core/dashboard_management.html', {'team_ratings': team_ratings})


# ---------------------------------------------------------------------------
# MODULE 2 — Players
# ---------------------------------------------------------------------------

@login_required
def player_list(request):
    players = Player.objects.select_related('team').all()

    q = request.GET.get('q', '').strip()
    role = request.GET.get('role', '')
    team_id = request.GET.get('team', '')
    batting_style = request.GET.get('batting_style', '')
    bowling_style = request.GET.get('bowling_style', '')

    if q:
        players = players.filter(Q(name__icontains=q))
    if role:
        players = players.filter(role=role)
    if team_id:
        players = players.filter(team_id=team_id)
    if batting_style:
        players = players.filter(batting_style=batting_style)
    if bowling_style:
        players = players.filter(bowling_style=bowling_style)

    context = {
        'players': players.order_by('name'),
        'teams': Team.objects.all(),
        'role_choices': Player.ROLE_CHOICES,
        'batting_style_choices': Player.BATTING_STYLE_CHOICES,
        'bowling_style_choices': Player.BOWLING_STYLE_CHOICES,
        'filters': request.GET,
    }
    return render(request, 'core/player_list.html', context)


@role_required('analyst')
def player_add(request):
    if request.method == 'POST':
        form = PlayerForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Player successfully added.")
            return redirect('player_list')
    else:
        form = PlayerForm()
    return render(request, 'core/player_form.html', {'form': form, 'mode': 'Add'})


@role_required('analyst')
def player_edit(request, pk):
    player = get_object_or_404(Player, pk=pk)
    if request.method == 'POST':
        form = PlayerForm(request.POST, request.FILES, instance=player)
        if form.is_valid():
            form.save()
            messages.success(request, "Player updated.")
            return redirect('player_detail', pk=player.pk)
    else:
        form = PlayerForm(instance=player)
    return render(request, 'core/player_form.html', {'form': form, 'mode': 'Edit', 'player': player})


@login_required
def player_detail(request, pk):
    player = get_object_or_404(Player, pk=pk)
    format = request.GET.get('format') or None

    context = {
        'player': player,
        'batting_stats': player.get_career_batting_stats(format=format),
        'bowling_stats': player.get_career_bowling_stats(format=format),
        'selected_format': format or 'Overall',
        'is_own_profile': (request.user.role == 'player' and request.user.player_id == player.id),
    }
    return render(request, 'core/player_detail.html', context)


@role_required('coach', 'analyst')
def player_compare(request):
    players = Player.objects.all().order_by('name')
    player_a = player_b = None
    stats_a = stats_b = None

    a_id = request.GET.get('player_a')
    b_id = request.GET.get('player_b')

    if a_id:
        player_a = get_object_or_404(Player, pk=a_id)
        stats_a = {
            'batting': player_a.get_career_batting_stats(),
            'bowling': player_a.get_career_bowling_stats(),
            'scores': calculate_performance_scores(player_a),
        }
    if b_id:
        player_b = get_object_or_404(Player, pk=b_id)
        stats_b = {
            'batting': player_b.get_career_batting_stats(),
            'bowling': player_b.get_career_bowling_stats(),
            'scores': calculate_performance_scores(player_b),
        }

    context = {
        'players': players,
        'player_a': player_a, 'player_b': player_b,
        'stats_a': stats_a, 'stats_b': stats_b,
    }
    return render(request, 'core/player_compare.html', context)


@login_required
def player_analytics(request, pk):
    player = get_object_or_404(Player, pk=pk)
    scores = calculate_performance_scores(player)
    strengths, weaknesses = get_strengths_weaknesses(player)

    recent_batting = list(
        player.battingperformance_set.select_related('match').order_by('-match__date')[:10]
    )[::-1]
    recent_bowling = list(
        player.bowlingperformance_set.select_related('match').order_by('-match__date')[:10]
    )[::-1]

    chart_data = {
        'labels': [bp.match.date.strftime('%d %b') for bp in recent_batting],
        'runs': [bp.runs for bp in recent_batting],
        'strike_rates': [bp.strike_rate() for bp in recent_batting],
        'bowling_labels': [bw.match.date.strftime('%d %b') for bw in recent_bowling],
        'wickets': [bw.wickets for bw in recent_bowling],
        'economies': [bw.economy() for bw in recent_bowling],
    }

    context = {
        'player': player,
        'scores': scores,
        'strengths': strengths,
        'weaknesses': weaknesses,
        'chart_data': chart_data,
        'has_bowling_data': bool(recent_bowling),
    }
    return render(request, 'core/player_analytics.html', context)


# ---------------------------------------------------------------------------
# MODULE 3 — Matches
# ---------------------------------------------------------------------------

@role_required('analyst', 'coach')
def match_create(request):
    if request.method == 'POST':
        form = MatchForm(request.POST)
        if form.is_valid():
            match = form.save()
            return redirect('match_select_xi', pk=match.pk)
    else:
        form = MatchForm()
    return render(request, 'core/match_form.html', {'form': form})


@role_required('analyst', 'coach')
def match_select_xi(request, pk):
    match = get_object_or_404(Match, pk=pk)
    team1_players = Player.objects.filter(team=match.team1)
    team2_players = Player.objects.filter(team=match.team2)

    if request.method == 'POST':
        team1_ids = request.POST.getlist('team1_players')
        team2_ids = request.POST.getlist('team2_players')

        if len(team1_ids) != 11 or len(team2_ids) != 11:
            messages.error(request, "You must select exactly 11 players for each team.")
        else:
            PlayingXI.objects.filter(match=match).delete()
            for pid in team1_ids:
                PlayingXI.objects.create(match=match, team=match.team1, player_id=pid)
            for pid in team2_ids:
                PlayingXI.objects.create(match=match, team=match.team2, player_id=pid)
            return redirect('match_enter_score', pk=match.pk)

    context = {
        'match': match,
        'team1_players': team1_players,
        'team2_players': team2_players,
    }
    return render(request, 'core/match_select_xi.html', context)


@role_required('analyst', 'coach')
def match_enter_score(request, pk):
    match = get_object_or_404(Match, pk=pk)
    team1_xi = PlayingXI.objects.filter(match=match, team=match.team1).select_related('player')
    team2_xi = PlayingXI.objects.filter(match=match, team=match.team2).select_related('player')

    if not team1_xi.exists() or not team2_xi.exists():
        messages.warning(request, "Select the Playing XI for both teams before entering the score.")
        return redirect('match_select_xi', pk=match.pk)

    all_batting_players = list(team1_xi) + list(team2_xi)
    all_bowling_players = list(team1_xi) + list(team2_xi)

    batting_initial = [
        {'player_id': x.player.id, 'player_name': x.player.name} for x in all_batting_players
    ]
    bowling_initial = [
        {'player_id': x.player.id, 'player_name': x.player.name} for x in all_bowling_players
    ]

    if request.method == 'POST':
        match_form = MatchScoreSummaryForm(request.POST)
        batting_fs = BattingFormSet(request.POST, prefix='bat', initial=batting_initial)
        bowling_fs = BowlingFormSet(request.POST, prefix='bowl', initial=bowling_initial)

        if match_form.is_valid() and batting_fs.is_valid() and bowling_fs.is_valid():
            cd = match_form.cleaned_data
            match.team1_score = cd['team1_score']
            match.team1_overs = cd['team1_overs']
            match.team2_score = cd['team2_score']
            match.team2_overs = cd['team2_overs']

            for row in batting_fs.cleaned_data:
                if not row:
                    continue
                BattingPerformance.objects.update_or_create(
                    match=match, player_id=row['player_id'],
                    defaults={
                        'runs': row['runs'], 'balls_faced': row['balls_faced'],
                        'fours': row['fours'], 'sixes': row['sixes'], 'is_out': row['is_out'],
                    }
                )
            for row in bowling_fs.cleaned_data:
                if not row:
                    continue
                BowlingPerformance.objects.update_or_create(
                    match=match, player_id=row['player_id'],
                    defaults={
                        'overs': row['overs'], 'runs_conceded': row['runs_conceded'],
                        'wickets': row['wickets'], 'maidens': row['maidens'],
                    }
                )

            # Auto-determine winner from final scores
            try:
                t1_runs = int(match.team1_score.split('/')[0])
                t2_runs = int(match.team2_score.split('/')[0])
                match.winner = match.team1 if t1_runs > t2_runs else match.team2
            except (ValueError, IndexError):
                match.winner = None

            match.save()
            messages.success(request, "Match successfully saved.")
            return redirect('match_detail', pk=match.pk)
    else:
        match_form = MatchScoreSummaryForm(initial={
            'team1_score': match.team1_score, 'team1_overs': match.team1_overs,
            'team2_score': match.team2_score, 'team2_overs': match.team2_overs,
        })
        batting_fs = BattingFormSet(prefix='bat', initial=batting_initial)
        bowling_fs = BowlingFormSet(prefix='bowl', initial=bowling_initial)

    context = {
        'match': match,
        'match_form': match_form,
        'batting_fs': batting_fs,
        'bowling_fs': bowling_fs,
    }
    return render(request, 'core/match_enter_score.html', context)


@login_required
def match_list(request):
    matches = Match.objects.select_related('team1', 'team2', 'winner').all().order_by('-date')

    format = request.GET.get('format', '')
    team_id = request.GET.get('team', '')

    if format:
        matches = matches.filter(format=format)
    if team_id:
        matches = matches.filter(Q(team1_id=team_id) | Q(team2_id=team_id))

    context = {
        'matches': matches,
        'teams': Team.objects.all(),
        'format_choices': Match.FORMAT_CHOICES,
        'filters': request.GET,
    }
    return render(request, 'core/match_list.html', context)


@login_required
def match_detail(request, pk):
    match = get_object_or_404(Match, pk=pk)
    team1_batting = BattingPerformance.objects.filter(
        match=match, player__in=Player.objects.filter(team=match.team1)
    ).select_related('player')
    team2_batting = BattingPerformance.objects.filter(
        match=match, player__in=Player.objects.filter(team=match.team2)
    ).select_related('player')
    team1_bowling = BowlingPerformance.objects.filter(
        match=match, player__in=Player.objects.filter(team=match.team1)
    ).select_related('player')
    team2_bowling = BowlingPerformance.objects.filter(
        match=match, player__in=Player.objects.filter(team=match.team2)
    ).select_related('player')

    context = {
        'match': match,
        'team1_batting': team1_batting, 'team2_batting': team2_batting,
        'team1_bowling': team1_bowling, 'team2_bowling': team2_bowling,
    }
    return render(request, 'core/match_detail.html', context)


@role_required('analyst', 'coach')
def match_delete(request, pk):
    match = get_object_or_404(Match, pk=pk)
    if request.method == 'POST':
        match.delete()
        messages.success(request, "Match deleted.")
        return redirect('match_list')
    return render(request, 'core/match_confirm_delete.html', {'match': match})


# ---------------------------------------------------------------------------
# MODULE 4 — Team dashboard
# ---------------------------------------------------------------------------

@login_required
def team_dashboard(request, pk):
    team = get_object_or_404(Team, pk=pk)
    ratings = get_team_ratings(team)
    players = team.players.all()
    return render(request, 'core/team_dashboard.html', {
        'team': team, 'ratings': ratings, 'players': players,
    })
