from functools import wraps
from django.shortcuts import render
from django.contrib.auth.decorators import login_required


def role_required(*roles):
    """
    Usage:
        @role_required('analyst')
        def my_view(request): ...

        @role_required('analyst', 'coach')
        def my_view(request): ...
    """
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped(request, *args, **kwargs):
            if request.user.role not in roles:
                return render(request, 'core/403.html', status=403)
            return view_func(request, *args, **kwargs)
        return _wrapped
    return decorator
