from django.contrib.auth.models import AbstractUser
from django.db import models


# ---------------------------------------------------------------------------
# MODULE 1 — Roles / Users
# ---------------------------------------------------------------------------

class User(AbstractUser):
    ROLE_CHOICES = [
        ('player', 'Player'),
        ('coach', 'Coach'),
        ('analyst', 'Analyst'),
        ('management', 'Management'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    # Only meaningful when role == 'player'
    player = models.ForeignKey(
        'core.Player', null=True, blank=True,
        on_delete=models.SET_NULL, related_name='linked_users'
    )

    def __str__(self):
        return f"{self.username} ({self.role})"


# ---------------------------------------------------------------------------
# MODULE 2 — Teams & Players
# ---------------------------------------------------------------------------

class Team(models.Model):
    team_name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.team_name


class Player(models.Model):
    ROLE_CHOICES = [
        ('Batsman', 'Batsman'),
        ('Bowler', 'Bowler'),
        ('All-rounder', 'All-rounder'),
        ('Wicketkeeper', 'Wicketkeeper'),
    ]
    BATTING_STYLE_CHOICES = [
        ('Right hand', 'Right hand'),
        ('Left hand', 'Left hand'),
    ]
    BOWLING_STYLE_CHOICES = [
        ('Right-arm fast', 'Right-arm fast'),
        ('Left-arm fast', 'Left-arm fast'),
        ('Right-arm medium', 'Right-arm medium'),
        ('Left-arm medium', 'Left-arm medium'),
        ('Off spin', 'Off spin'),
        ('Leg spin', 'Leg spin'),
        ('Left-arm orthodox', 'Left-arm orthodox'),
        ('None', 'None'),
    ]

    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField(null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    nationality = models.CharField(max_length=60, blank=True)
    profile_picture = models.ImageField(upload_to='players/', null=True, blank=True)
    team = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name='players')
    jersey_number = models.PositiveIntegerField(null=True, blank=True)

    height_cm = models.FloatField(null=True, blank=True)
    weight_kg = models.FloatField(null=True, blank=True)

    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    batting_style = models.CharField(max_length=20, choices=BATTING_STYLE_CHOICES, blank=True)
    bowling_style = models.CharField(max_length=30, choices=BOWLING_STYLE_CHOICES, blank=True)

    # Fielding stats (Module 2.4)
    catches = models.PositiveIntegerField(default=0)
    run_outs = models.PositiveIntegerField(default=0)
    stumpings = models.PositiveIntegerField(default=0)
    dropped_catches = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.name

    # -- Career stats aggregation (Module 2.2 / 2.3) -----------------------
    def get_career_batting_stats(self, format=None):
        from core.analytics import compute_batting_stats
        qs = self.battingperformance_set.all()
        if format:
            qs = qs.filter(match__format=format)
        return compute_batting_stats(qs)

    def get_career_bowling_stats(self, format=None):
        from core.analytics import compute_bowling_stats
        qs = self.bowlingperformance_set.all()
        if format:
            qs = qs.filter(match__format=format)
        return compute_bowling_stats(qs)


# ---------------------------------------------------------------------------
# MODULE 3 — Matches
# ---------------------------------------------------------------------------

class Match(models.Model):
    FORMAT_CHOICES = [('Test', 'Test'), ('ODI', 'ODI'), ('T20', 'T20')]
    DECISION_CHOICES = [('Bat', 'Bat'), ('Bowl', 'Bowl')]

    date = models.DateField()
    format = models.CharField(max_length=10, choices=FORMAT_CHOICES)
    venue = models.CharField(max_length=150, blank=True)

    team1 = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='matches_as_team1')
    team2 = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='matches_as_team2')

    toss_winner = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')
    toss_decision = models.CharField(max_length=10, choices=DECISION_CHOICES, blank=True)

    team1_score = models.CharField(max_length=20, blank=True)   # e.g. "186/6"
    team1_overs = models.FloatField(null=True, blank=True)
    team2_score = models.CharField(max_length=20, blank=True)
    team2_overs = models.FloatField(null=True, blank=True)

    winner = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name='+')

    def __str__(self):
        return f"{self.team1} vs {self.team2} - {self.date}"

    def result_text(self):
        if not self.winner:
            return "Result pending"
        try:
            t1_runs = int(self.team1_score.split('/')[0])
            t2_runs = int(self.team2_score.split('/')[0])
            margin = abs(t1_runs - t2_runs)
            return f"{self.winner.team_name} won by {margin} runs"
        except (ValueError, IndexError, AttributeError):
            return f"{self.winner.team_name} won"


class PlayingXI(models.Model):
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name='playing_xi')
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    player = models.ForeignKey(Player, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('match', 'team', 'player')

    def __str__(self):
        return f"{self.player} - {self.team} ({self.match})"


class BattingPerformance(models.Model):
    match = models.ForeignKey(Match, on_delete=models.CASCADE)
    player = models.ForeignKey(Player, on_delete=models.CASCADE)
    runs = models.PositiveIntegerField(default=0)
    balls_faced = models.PositiveIntegerField(default=0)
    fours = models.PositiveIntegerField(default=0)
    sixes = models.PositiveIntegerField(default=0)
    is_out = models.BooleanField(default=True)

    class Meta:
        unique_together = ('match', 'player')

    def strike_rate(self):
        if self.balls_faced == 0:
            return 0.0
        return round((self.runs / self.balls_faced) * 100, 2)

    def __str__(self):
        return f"{self.player} - {self.runs}({self.balls_faced}) in {self.match}"


class BowlingPerformance(models.Model):
    match = models.ForeignKey(Match, on_delete=models.CASCADE)
    player = models.ForeignKey(Player, on_delete=models.CASCADE)
    overs = models.FloatField(default=0)
    runs_conceded = models.PositiveIntegerField(default=0)
    wickets = models.PositiveIntegerField(default=0)
    maidens = models.PositiveIntegerField(default=0)

    class Meta:
        unique_together = ('match', 'player')

    def economy(self):
        if not self.overs:
            return 0.0
        return round(self.runs_conceded / self.overs, 2)

    def __str__(self):
        return f"{self.player} - {self.wickets}/{self.runs_conceded} in {self.match}"
