from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, Team, Player, Match, PlayingXI,
    BattingPerformance, BowlingPerformance,
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'role', 'player', 'is_staff')
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Cricket role', {'fields': ('role', 'player')}),
    )


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('team_name',)
    search_fields = ('team_name',)


@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    list_display = ('name', 'team', 'role', 'batting_style', 'bowling_style', 'jersey_number')
    list_filter = ('role', 'team', 'batting_style')
    search_fields = ('name',)


@admin.register(Match)
class MatchAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'format', 'date', 'team1_score', 'team2_score', 'winner')
    list_filter = ('format', 'date')


admin.site.register(PlayingXI)
admin.site.register(BattingPerformance)
admin.site.register(BowlingPerformance)
