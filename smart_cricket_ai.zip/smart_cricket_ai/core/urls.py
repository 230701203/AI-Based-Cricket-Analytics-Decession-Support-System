from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_redirect, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('dashboard/player/', views.dashboard_player, name='dashboard_player'),
    path('dashboard/coach/', views.dashboard_coach, name='dashboard_coach'),
    path('dashboard/analyst/', views.dashboard_analyst, name='dashboard_analyst'),
    path('dashboard/management/', views.dashboard_management, name='dashboard_management'),

    path('players/', views.player_list, name='player_list'),
    path('players/add/', views.player_add, name='player_add'),
    path('players/compare/', views.player_compare, name='player_compare'),
    path('players/<int:pk>/', views.player_detail, name='player_detail'),
    path('players/<int:pk>/edit/', views.player_edit, name='player_edit'),
    path('players/<int:pk>/analytics/', views.player_analytics, name='player_analytics'),

    path('matches/', views.match_list, name='match_list'),
    path('matches/new/', views.match_create, name='match_create'),
    path('matches/<int:pk>/', views.match_detail, name='match_detail'),
    path('matches/<int:pk>/select-xi/', views.match_select_xi, name='match_select_xi'),
    path('matches/<int:pk>/enter-score/', views.match_enter_score, name='match_enter_score'),
    path('matches/<int:pk>/delete/', views.match_delete, name='match_delete'),

    path('teams/<int:pk>/', views.team_dashboard, name='team_dashboard'),
]
