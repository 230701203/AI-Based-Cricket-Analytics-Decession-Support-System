# Smart Cricket AI — Phase 1

Django + SQLite + Bootstrap 5 + Chart.js.

## Setup (in VS Code terminal)

```bash
# 1. Create and activate a virtual environment
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # Mac/Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run migrations
python manage.py makemigrations
python manage.py migrate

# 4. Seed demo data (3 teams, 20 players, 4 test login users)
python manage.py seed_demo_data

# 5. (Optional) create your own admin superuser
python manage.py createsuperuser

# 6. Run the server
python manage.py runserver
```

Visit http://127.0.0.1:8000/

## Demo logins (created by seed_demo_data)
| Username | Password | Role |
|---|---|---|
| player1  | pass1234 | Player (linked to a real seeded player) |
| coach1   | pass1234 | Coach |
| analyst1 | pass1234 | Analyst |
| mgmt1    | pass1234 | Management |

## What's implemented (Modules 1-4)
- **Module 1**: Custom User model with 4 roles, login/logout, role-gated dashboards and views (`core/decorators.py::role_required`)
- **Module 2**: Player model (personal/physical/role fields), career batting & bowling stat aggregation (format-filterable), Add/Edit Player, Search & Filter, Player Comparison
- **Module 3**: Match creation → Playing XI selection (11 per team) → score entry (batting/bowling formsets) → auto-calculated stats → Match History → Scorecard view
- **Module 4**: Rule-based performance scoring engine (`core/analytics.py`), AI classification (Excellent/Very Good/Good/Average/Poor), strengths/weaknesses, per-player Chart.js graphs, team-level ratings dashboard

## Not implemented yet (intentionally, per the 2-day scope)
- CSV import (button is present but disabled)
- Playing XI recommendation AI, opponent analysis, auction AI, video analysis
- Player value/budget (Management dashboard shows "Coming soon")

## Next step after the 2-day sprint
Swap the rule-based formulas in `core/analytics.py` (`calculate_performance_scores`,
`get_strengths_weaknesses`) for a trained Random Forest / XGBoost model — the
function signatures used by the templates won't need to change.

## Switching from SQLite to PostgreSQL later
Edit the `DATABASES` block in `smart_cricket_ai/settings.py` — the commented-out
PostgreSQL config is already there. No other code changes needed.
